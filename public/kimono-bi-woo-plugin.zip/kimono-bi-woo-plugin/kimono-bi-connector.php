<?php
/**
 * Plugin Name: Kimono BI Connector
 * Plugin URI: https://bi.kimonogroup.ro
 * Description: Conecteaza magazinul WooCommerce la platforma Kimono BI. Include import/export cost produse, alerte, si dashboard widget.
 * Version: 1.2.0
 * Author: Kimono Group
 * Author URI: https://kimonogroup.ro
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * License: GPL-2.0+
 * Text Domain: kimono-bi
 */

if (!defined('ABSPATH')) exit;

if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    add_action('admin_notices', function() {
        echo '<div class="notice notice-error"><p><strong>Kimono BI Connector</strong> necesita WooCommerce activ.</p></div>';
    });
    return;
}

define('KIMONO_BI_VERSION', '1.2.0');
define('KIMONO_BI_PATH', plugin_dir_path(__FILE__));

// ═══════════════════════════════════════════════
// ACTIVATION
// ═══════════════════════════════════════════════

register_activation_hook(__FILE__, function() {
    if (!get_option('kimono_bi_api_key')) {
        update_option('kimono_bi_api_key', wp_generate_password(32, false));
    }
    update_option('kimono_bi_activated_at', current_time('mysql'));
});

// ═══════════════════════════════════════════════
// ADMIN SETTINGS PAGE
// ═══════════════════════════════════════════════

add_action('admin_menu', function() {
    add_submenu_page('woocommerce', 'Kimono BI', 'Kimono BI', 'manage_woocommerce', 'kimono-bi', 'kimono_bi_settings_page');
});

function kimono_bi_settings_page() {
    $tab = isset($_GET['section']) ? sanitize_text_field($_GET['section']) : 'connection';

    // Handle actions
    if (isset($_POST['kimono_bi_regenerate']) && wp_verify_nonce($_POST['_wpnonce'], 'kimono_bi_regen')) {
        update_option('kimono_bi_api_key', wp_generate_password(32, false));
        echo '<div class="notice notice-success"><p>Cheie API regenerata cu succes.</p></div>';
    }

    // Handle CSV import
    if (isset($_POST['kimono_bi_import_csv']) && wp_verify_nonce($_POST['_wpnonce'], 'kimono_bi_csv')) {
        kimono_bi_handle_csv_import();
    }

    $api_key = get_option('kimono_bi_api_key');
    $site_url = get_site_url();
    ?>
    <div class="wrap">
        <h1 style="display:flex;align-items:center;gap:10px;">
            <span style="background:#FF5A1F;color:#fff;width:32px;height:32px;border-radius:8px;display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;">K</span>
            Kimono BI Connector
        </h1>

        <!-- Tabs -->
        <nav class="nav-tab-wrapper" style="margin-bottom:20px;">
            <a href="?page=kimono-bi&section=connection" class="nav-tab <?php echo $tab === 'connection' ? 'nav-tab-active' : ''; ?>">Conexiune</a>
            <a href="?page=kimono-bi&section=costs" class="nav-tab <?php echo $tab === 'costs' ? 'nav-tab-active' : ''; ?>">Cost Produse</a>
            <a href="?page=kimono-bi&section=status" class="nav-tab <?php echo $tab === 'status' ? 'nav-tab-active' : ''; ?>">Status</a>
        </nav>

        <?php
        if ($tab === 'connection') kimono_bi_tab_connection($api_key, $site_url);
        elseif ($tab === 'costs') kimono_bi_tab_costs();
        elseif ($tab === 'status') kimono_bi_tab_status();
        ?>
    </div>
    <?php
}

// ─── Connection Tab ───
function kimono_bi_tab_connection($api_key, $site_url) {
    ?>
    <div style="max-width:700px;background:#fff;border:1px solid #ddd;border-radius:8px;padding:24px;">
        <h2 style="margin-top:0;">Configurare conexiune</h2>
        <p>Foloseste aceste date in <a href="https://bi.kimonogroup.ro" target="_blank">Kimono BI</a> pentru a conecta magazinul:</p>
        <table class="form-table">
            <tr>
                <th>URL Magazin</th>
                <td><input type="text" value="<?php echo esc_attr($site_url); ?>" readonly class="large-text" onclick="this.select();" /></td>
            </tr>
            <tr>
                <th>Cheie API</th>
                <td>
                    <input type="text" value="<?php echo esc_attr($api_key); ?>" readonly class="large-text" onclick="this.select();" style="font-family:monospace;background:#f0f0f0;" />
                    <p class="description">Copiaza aceasta cheie in Kimono BI la conectarea magazinului.</p>
                </td>
            </tr>
            <tr>
                <th>Endpoint API</th>
                <td><code style="font-size:13px;"><?php echo esc_html($site_url); ?>/wp-json/kimono-bi/v1/</code></td>
            </tr>
        </table>
        <form method="post">
            <?php wp_nonce_field('kimono_bi_regen'); ?>
            <button type="submit" name="kimono_bi_regenerate" class="button" onclick="return confirm('Regenerezi cheia? Conexiunea actuala cu Kimono BI se va pierde.');">Regenereaza cheie API</button>
        </form>
    </div>
    <?php
}

// ─── Costs Tab (CSV Import/Export + Missing Costs Alert) ───
function kimono_bi_tab_costs() {
    global $wpdb;

    // Count products without cost
    $total_products = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status IN ('publish','draft')");
    // Count products with cost (including variable products where at least one variation has cost)
    $products_with_cost = (int) $wpdb->get_var(
        "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
         WHERE p.post_type = 'product' AND p.post_status IN ('publish','draft')
         AND (
           EXISTS (SELECT 1 FROM {$wpdb->postmeta} pm WHERE pm.post_id = p.ID AND pm.meta_key = '_cost_per_unit' AND pm.meta_value != '' AND pm.meta_value != '0')
           OR EXISTS (SELECT 1 FROM {$wpdb->posts} v INNER JOIN {$wpdb->postmeta} vm ON v.ID = vm.post_id WHERE v.post_parent = p.ID AND v.post_type = 'product_variation' AND vm.meta_key = '_cost_per_unit' AND vm.meta_value != '' AND vm.meta_value != '0')
         )"
    );
    $missing_cost = $total_products - $products_with_cost;
    $pct = $total_products > 0 ? round(($products_with_cost / $total_products) * 100) : 0;
    ?>
    <div style="max-width:800px;">

        <!-- Missing Cost Alert -->
        <div style="background:<?php echo $missing_cost > 0 ? '#fff3cd' : '#d4edda'; ?>;border:1px solid <?php echo $missing_cost > 0 ? '#ffc107' : '#28a745'; ?>;border-radius:8px;padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:12px;">
            <span style="font-size:24px;"><?php echo $missing_cost > 0 ? '⚠️' : '✅'; ?></span>
            <div>
                <strong><?php echo $products_with_cost; ?> din <?php echo $total_products; ?> produse au cost setat (<?php echo $pct; ?>%)</strong>
                <?php if ($missing_cost > 0): ?>
                    <br/><span style="color:#856404;"><?php echo $missing_cost; ?> produse fara cost — marja de profit nu poate fi calculata pentru ele.</span>
                <?php else: ?>
                    <br/><span style="color:#155724;">Toate produsele au cost setat. Marja se calculeaza corect.</span>
                <?php endif; ?>
            </div>
        </div>

        <!-- CSV Import -->
        <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:24px;margin-bottom:20px;">
            <h2 style="margin-top:0;">Import cost produse din CSV</h2>
            <p>Uploadeaza un fisier CSV cu 2 coloane: <code>SKU</code> si <code>cost</code>. Costul se va actualiza pe toate produsele gasite dupa SKU.</p>
            <div style="background:#e8f4fd;border:1px solid #bee5eb;border-radius:6px;padding:10px 14px;margin-bottom:12px;font-size:12px;color:#0c5460;"><strong>Important:</strong> Import-ul functioneaza doar pentru produsele care au SKU setat in WooCommerce. Produsele fara SKU nu vor fi gasite. Un magazin profesional ar trebui sa aiba SKU-uri unice pe toate produsele.</div>
            <p style="color:#666;font-size:12px;">Format acceptat: CSV cu separator virgula (,) sau punct si virgula (;). Prima linie = header. Costul poate folosi punct sau virgula ca separator zecimal.</p>

            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field('kimono_bi_csv'); ?>
                <table class="form-table">
                    <tr>
                        <th>Fisier CSV</th>
                        <td>
                            <input type="file" name="cost_csv" accept=".csv,.txt" required />
                            <p class="description">Exemplu continut:<br/><code>SKU,cost<br/>PROD-001,25.50<br/>PROD-002,12.00</code></p>
                        </td>
                    </tr>
                </table>
                <button type="submit" name="kimono_bi_import_csv" class="button button-primary" style="background:#FF5A1F;border-color:#FF5A1F;">Import CSV</button>
            </form>
        </div>

        <!-- CSV Export -->
        <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:24px;margin-bottom:20px;">
            <h2 style="margin-top:0;">Export cost produse</h2>
            <p>Descarca un CSV cu toate produsele (SKU, nume, pret, cost actual). Poti completa coloana cost si sa re-importi.</p>
            <a href="<?php echo admin_url('admin-ajax.php?action=kimono_bi_export_costs&_wpnonce=' . wp_create_nonce('kimono_bi_export')); ?>" class="button button-secondary">Descarca CSV</a>
        </div>

        <!-- Quick Stats -->
        <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:24px;">
            <h2 style="margin-top:0;">Produse fara cost (primele 20)</h2>
            <?php
            $no_cost = $wpdb->get_results(
                "SELECT p.ID, p.post_title, pm_sku.meta_value as sku, pm_price.meta_value as price
                 FROM {$wpdb->posts} p
                 LEFT JOIN {$wpdb->postmeta} pm_sku ON p.ID = pm_sku.post_id AND pm_sku.meta_key = '_sku'
                 LEFT JOIN {$wpdb->postmeta} pm_price ON p.ID = pm_price.post_id AND pm_price.meta_key = '_price'
                 LEFT JOIN {$wpdb->postmeta} pm_cost ON p.ID = pm_cost.post_id AND pm_cost.meta_key = '_cost_per_unit'
                 WHERE p.post_type = 'product' AND p.post_status = 'publish'
                 AND (pm_cost.meta_value IS NULL OR pm_cost.meta_value = '' OR pm_cost.meta_value = '0')
                 AND NOT EXISTS (SELECT 1 FROM {$wpdb->posts} v INNER JOIN {$wpdb->postmeta} vm ON v.ID = vm.post_id WHERE v.post_parent = p.ID AND v.post_type = 'product_variation' AND vm.meta_key = '_cost_per_unit' AND vm.meta_value != '' AND vm.meta_value != '0')
                 ORDER BY pm_price.meta_value+0 DESC
                 LIMIT 20"
            );
            if ($no_cost): ?>
                <table class="widefat striped" style="margin-top:12px;">
                    <thead><tr><th>SKU</th><th>Produs</th><th>Pret</th><th>Actiune</th></tr></thead>
                    <tbody>
                    <?php foreach ($no_cost as $p): ?>
                        <tr>
                            <td><code><?php echo esc_html($p->sku ?: '—'); ?></code></td>
                            <td><?php echo esc_html(mb_substr($p->post_title, 0, 60)); ?></td>
                            <td><?php echo $p->price ? wc_price($p->price) : '—'; ?></td>
                            <td><a href="<?php echo get_edit_post_link($p->ID); ?>" class="button button-small">Edit</a></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p style="color:green;">Toate produsele au cost setat!</p>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

// ─── Status Tab ───
function kimono_bi_tab_status() {
    $last_sync = get_option('kimono_bi_last_sync', 'Niciodata');
    $last_sync_count = get_option('kimono_bi_last_sync_count', '—');
    $activated_at = get_option('kimono_bi_activated_at', '—');
    ?>
    <div style="max-width:700px;background:#fff;border:1px solid #ddd;border-radius:8px;padding:24px;">
        <h2 style="margin-top:0;">Status plugin</h2>
        <table class="form-table">
            <tr><th>Plugin</th><td><strong style="color:green;">Activ v<?php echo KIMONO_BI_VERSION; ?></strong></td></tr>
            <tr><th>WooCommerce</th><td><?php echo WC_VERSION; ?></td></tr>
            <tr><th>WordPress</th><td><?php echo get_bloginfo('version'); ?></td></tr>
            <tr><th>PHP</th><td><?php echo PHP_VERSION; ?></td></tr>
            <tr><th>Activat la</th><td><?php echo esc_html($activated_at); ?></td></tr>
            <tr><th>Ultimul sync Kimono BI</th><td><?php echo esc_html($last_sync); ?></td></tr>
            <tr><th>Entitati sincronizate</th><td><?php echo esc_html($last_sync_count); ?></td></tr>
            <tr><th>Memory limit</th><td><?php echo ini_get('memory_limit'); ?></td></tr>
            <tr><th>Max execution time</th><td><?php echo ini_get('max_execution_time'); ?>s</td></tr>
        </table>

        <h3>Test conexiune</h3>
        <p>Testeaza daca API-ul functioneaza:</p>
        <code style="display:block;background:#f5f5f5;padding:10px;border-radius:4px;font-size:12px;word-break:break-all;">
            curl -H "X-Kimono-BI-Key: <?php echo esc_html(get_option('kimono_bi_api_key')); ?>" <?php echo esc_html(get_site_url()); ?>/wp-json/kimono-bi/v1/ping
        </code>
    </div>
    <?php
}

// ═══════════════════════════════════════════════
// CSV IMPORT HANDLER
// ═══════════════════════════════════════════════

function kimono_bi_handle_csv_import() {
    if (!isset($_FILES['cost_csv']) || $_FILES['cost_csv']['error'] !== UPLOAD_ERR_OK) {
        echo '<div class="notice notice-error"><p>Eroare la upload fisier.</p></div>';
        return;
    }

    $file = $_FILES['cost_csv']['tmp_name'];
    $handle = fopen($file, 'r');
    if (!$handle) {
        echo '<div class="notice notice-error"><p>Nu pot deschide fisierul.</p></div>';
        return;
    }

    // Detect separator
    $first_line = fgets($handle);
    rewind($handle);
    $separator = strpos($first_line, ';') !== false ? ';' : ',';

    // Skip header
    $header = fgetcsv($handle, 0, $separator);
    if (!$header) {
        fclose($handle);
        echo '<div class="notice notice-error"><p>Fisier CSV gol sau invalid.</p></div>';
        return;
    }

    // Find column indexes
    $header_lower = array_map('strtolower', array_map('trim', $header));
    $sku_idx = array_search('sku', $header_lower);
    $cost_idx = array_search('cost', $header_lower);
    if ($cost_idx === false) $cost_idx = array_search('cost_per_unit', $header_lower);
    if ($cost_idx === false) $cost_idx = array_search('costperunit', $header_lower);
    if ($cost_idx === false) $cost_idx = array_search('pret_achizitie', $header_lower);
    if ($cost_idx === false) $cost_idx = array_search('cost_achizitie', $header_lower);

    if ($sku_idx === false || $cost_idx === false) {
        fclose($handle);
        echo '<div class="notice notice-error"><p>CSV trebuie sa contina coloanele <strong>SKU</strong> si <strong>cost</strong> (sau cost_per_unit, pret_achizitie).</p></div>';
        return;
    }

    global $wpdb;
    $updated = 0;
    $not_found = 0;
    $errors = [];

    while (($row = fgetcsv($handle, 0, $separator)) !== false) {
        if (count($row) <= max($sku_idx, $cost_idx)) continue;

        $sku = trim($row[$sku_idx]);
        $cost = trim($row[$cost_idx]);

        if (empty($sku) || $cost === '') continue;

        // Normalize cost: replace comma with dot
        $cost = str_replace(',', '.', $cost);
        $cost = floatval($cost);

        if ($cost < 0) continue;

        // Find product by SKU (works with variations + HPOS)
        $product_id = wc_get_product_id_by_sku($sku);

        // Fallback: if SKU not found and has variation suffix (-a1, -a2, etc),
        // try parent SKU without suffix
        if (!$product_id && preg_match('/^(.+)-[a-z]?\d+$/', $sku, $m)) {
            $parent_sku = $m[1];
            $product_id = wc_get_product_id_by_sku($parent_sku);
        }

        // Fallback 2: search by product title + price matching for variations
        if (!$product_id) {
            // Get title and price from CSV row
            $csv_title = isset($row[$sku_idx + 1]) ? trim($row[$sku_idx + 1]) : '';
            $csv_price = isset($row[$sku_idx + 2]) ? floatval(str_replace(',', '.', trim($row[$sku_idx + 2]))) : 0;

            if ($csv_title) {
                // First try: find a variation with matching title AND price
                if ($csv_price > 0) {
                    $found = $wpdb->get_var($wpdb->prepare(
                        "SELECT p.ID FROM {$wpdb->posts} p
                         INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_price'
                         WHERE p.post_type = 'product_variation' AND p.post_title = %s
                         AND CAST(pm.meta_value AS DECIMAL(10,2)) = %f
                         LIMIT 1",
                        $csv_title, $csv_price
                    ));
                    if ($found) $product_id = (int)$found;
                }

                // If no variation match, try parent product by title
                if (!$product_id) {
                    $found = $wpdb->get_var($wpdb->prepare(
                        "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'product' AND post_title = %s LIMIT 1",
                        $csv_title
                    ));
                    if ($found) {
                        $parent_product = wc_get_product((int)$found);
                        if ($parent_product && $parent_product->is_type('variable') && $csv_price > 0) {
                            // Find the specific variation by price
                            foreach ($parent_product->get_children() as $var_id) {
                                $var_price = floatval(get_post_meta($var_id, '_price', true));
                                if (abs($var_price - $csv_price) < 0.01) {
                                    $product_id = $var_id;
                                    break;
                                }
                            }
                            // If no price match, set on parent only (don't propagate)
                            if (!$product_id) $product_id = (int)$found;
                        } else {
                            $product_id = (int)$found;
                        }
                    }
                }
            }
        }

        if ($product_id) {
            $formatted_cost = wc_format_decimal($cost);
            update_post_meta($product_id, '_cost_per_unit', $formatted_cost);
            $updated++;

            // If matched by exact SKU on parent, propagate to variations without cost
            $product = wc_get_product($product_id);
            if ($product && $product->is_type('variable') && wc_get_product_id_by_sku($sku) == $product_id) {
                foreach ($product->get_children() as $var_id) {
                    $existing = get_post_meta($var_id, '_cost_per_unit', true);
                    if (!$existing || floatval($existing) == 0) {
                        update_post_meta($var_id, '_cost_per_unit', $formatted_cost);
                    }
                }
            }

            // If this is a variation, also set on parent
            if ($product && $product->is_type('variation')) {
                $parent_id = $product->get_parent_id();
                if ($parent_id) {
                    $parent_cost = get_post_meta($parent_id, '_cost_per_unit', true);
                    if (!$parent_cost || floatval($parent_cost) == 0) {
                        update_post_meta($parent_id, '_cost_per_unit', $formatted_cost);
                    }
                }
            }
        } else {
            $not_found++;
            if ($not_found <= 5) $errors[] = $sku;
        }
    }

    fclose($handle);

    $msg = "<strong>{$updated} produse actualizate cu succes.</strong>";
    if ($not_found > 0) {
        $msg .= " {$not_found} SKU-uri negasite.";
        if (!empty($errors)) $msg .= " Primele: " . implode(', ', $errors);
    }
    echo '<div class="notice notice-' . ($not_found > 0 ? 'warning' : 'success') . '"><p>' . $msg . '</p></div>';
}

// ═══════════════════════════════════════════════
// CSV EXPORT HANDLER
// ═══════════════════════════════════════════════

add_action('wp_ajax_kimono_bi_export_costs', function() {
    if (!wp_verify_nonce($_GET['_wpnonce'], 'kimono_bi_export') || !current_user_can('manage_woocommerce')) {
        wp_die('Unauthorized');
    }

    global $wpdb;
    $products = $wpdb->get_results(
        "SELECT p.ID, p.post_title,
                pm_sku.meta_value as sku,
                pm_price.meta_value as price,
                pm_cost.meta_value as cost_per_unit
         FROM {$wpdb->posts} p
         LEFT JOIN {$wpdb->postmeta} pm_sku ON p.ID = pm_sku.post_id AND pm_sku.meta_key = '_sku'
         LEFT JOIN {$wpdb->postmeta} pm_price ON p.ID = pm_price.post_id AND pm_price.meta_key = '_price'
         LEFT JOIN {$wpdb->postmeta} pm_cost ON p.ID = pm_cost.post_id AND pm_cost.meta_key = '_cost_per_unit'
         WHERE p.post_type = 'product' AND p.post_status IN ('publish','draft')
         ORDER BY p.post_title ASC"
    );

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="kimono-bi-costs-' . date('Y-m-d') . '.csv"');

    $out = fopen('php://output', 'w');
    // BOM for Excel
    fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));
    fputcsv($out, ['SKU', 'produs', 'pret', 'cost', 'marja_pct']);

    foreach ($products as $p) {
        $price = floatval($p->price);
        $cost = floatval($p->cost_per_unit);
        $margin_pct = ($price > 0 && $cost > 0) ? round((($price - $cost) / $price) * 100, 1) : '';

        fputcsv($out, [
            $p->sku ?: '',
            $p->post_title,
            $price ?: '',
            $cost ?: '',
            $margin_pct,
        ]);
    }

    fclose($out);
    exit;
});

// ═══════════════════════════════════════════════
// ADMIN NOTICE — MISSING COSTS
// ═══════════════════════════════════════════════

add_action('admin_notices', function() {
    if (!current_user_can('manage_woocommerce')) return;
    $screen = get_current_screen();
    if (!$screen || !in_array($screen->id, ['dashboard', 'edit-product', 'product'])) return;

    // Cache check (only show once per day)
    $last_check = get_transient('kimono_bi_cost_check');
    if ($last_check !== false) return;

    global $wpdb;
    $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status = 'publish'");
    $with_cost = (int) $wpdb->get_var(
        "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
         WHERE p.post_type = 'product' AND p.post_status = 'publish'
         AND (
           EXISTS (SELECT 1 FROM {$wpdb->postmeta} pm WHERE pm.post_id = p.ID AND pm.meta_key = '_cost_per_unit' AND pm.meta_value != '' AND pm.meta_value != '0')
           OR EXISTS (SELECT 1 FROM {$wpdb->posts} v INNER JOIN {$wpdb->postmeta} vm ON v.ID = vm.post_id WHERE v.post_parent = p.ID AND v.post_type = 'product_variation' AND vm.meta_key = '_cost_per_unit' AND vm.meta_value != '' AND vm.meta_value != '0')
         )"
    );
    $missing = $total - $with_cost;

    if ($missing > 0 && $missing > ($total * 0.1)) { // Only show if >10% missing
        echo '<div class="notice notice-warning is-dismissible"><p>';
        echo '<strong>Kimono BI:</strong> ' . $missing . ' din ' . $total . ' produse nu au cost setat. ';
        echo '<a href="' . admin_url('admin.php?page=kimono-bi&section=costs') . '">Importa costuri din CSV</a>';
        echo '</p></div>';
    }

    set_transient('kimono_bi_cost_check', 1, DAY_IN_SECONDS);
});

// ═══════════════════════════════════════════════
// DASHBOARD WIDGET — SYNC STATUS
// ═══════════════════════════════════════════════

add_action('wp_dashboard_setup', function() {
    if (!current_user_can('manage_woocommerce')) return;
    wp_add_dashboard_widget('kimono_bi_widget', 'Kimono BI — Status', 'kimono_bi_dashboard_widget');
});

function kimono_bi_dashboard_widget() {
    global $wpdb;
    $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status = 'publish'");
    $orders = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'shop_order'");
    $with_cost = (int) $wpdb->get_var(
        "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
         WHERE p.post_type = 'product' AND p.post_status = 'publish'
         AND (
           EXISTS (SELECT 1 FROM {$wpdb->postmeta} pm WHERE pm.post_id = p.ID AND pm.meta_key = '_cost_per_unit' AND pm.meta_value != '' AND pm.meta_value != '0')
           OR EXISTS (SELECT 1 FROM {$wpdb->posts} v INNER JOIN {$wpdb->postmeta} vm ON v.ID = vm.post_id WHERE v.post_parent = p.ID AND v.post_type = 'product_variation' AND vm.meta_key = '_cost_per_unit' AND vm.meta_value != '' AND vm.meta_value != '0')
         )"
    );
    $last_sync = get_option('kimono_bi_last_sync', 'Niciodata');
    $pct = $total > 0 ? round(($with_cost / $total) * 100) : 0;
    ?>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <div style="background:#f8f9fa;padding:12px;border-radius:6px;text-align:center;">
            <div style="font-size:24px;font-weight:700;color:#FF5A1F;"><?php echo number_format($orders); ?></div>
            <div style="font-size:11px;color:#666;">Comenzi</div>
        </div>
        <div style="background:#f8f9fa;padding:12px;border-radius:6px;text-align:center;">
            <div style="font-size:24px;font-weight:700;color:#0073aa;"><?php echo number_format($total); ?></div>
            <div style="font-size:11px;color:#666;">Produse</div>
        </div>
    </div>
    <div style="margin-top:12px;">
        <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px;">
            <span>Cost setat: <?php echo $with_cost; ?>/<?php echo $total; ?></span>
            <span style="color:<?php echo $pct >= 80 ? 'green' : ($pct >= 50 ? '#e67e22' : 'red'); ?>;"><?php echo $pct; ?>%</span>
        </div>
        <div style="height:6px;background:#eee;border-radius:3px;overflow:hidden;">
            <div style="height:100%;width:<?php echo $pct; ?>%;background:<?php echo $pct >= 80 ? '#28a745' : ($pct >= 50 ? '#ffc107' : '#dc3545'); ?>;border-radius:3px;"></div>
        </div>
    </div>
    <p style="font-size:11px;color:#888;margin-top:8px;">Ultimul sync: <?php echo esc_html($last_sync); ?></p>
    <p style="margin:8px 0 0;"><a href="<?php echo admin_url('admin.php?page=kimono-bi'); ?>" class="button button-small">Setari Kimono BI</a></p>
    <?php
}

// ═══════════════════════════════════════════════
// COST COLUMN + QUICK EDIT IN PRODUCTS LIST
// ═══════════════════════════════════════════════

// Add cost + margin columns
// Add Cost & Margin columns (priority 20 = after WooCommerce)
add_filter('manage_edit-product_columns', function($columns) {
    $new = [];
    foreach ($columns as $key => $val) {
        $new[$key] = $val;
        if ($key === 'price') {
            $new['kimono_cost'] = 'Cost';
            $new['kimono_margin'] = 'Marja';
        }
    }
    return $new;
}, 20);

add_action('admin_head', function() {
    $screen = get_current_screen();
    if (!$screen || $screen->id !== 'edit-product') return;
    echo '<style>
        th.column-kimono_cost, td.column-kimono_cost { width: 80px; white-space: nowrap; text-align: left; }
        th.column-kimono_margin, td.column-kimono_margin { width: 65px; white-space: nowrap; text-align: left; }
        td.column-kimono_cost, td.column-kimono_margin { overflow: visible !important; }
    </style>';
});

add_action('manage_product_posts_custom_column', function($column, $post_id) {
    if ($column === 'kimono_cost') {
        $product = wc_get_product($post_id);
        if ($product && $product->is_type('variable')) {
            $costs = [];
            foreach ($product->get_children() as $var_id) {
                $vc = floatval(get_post_meta($var_id, '_cost_per_unit', true));
                if ($vc > 0) $costs[] = $vc;
            }
            if (!empty($costs)) {
                $min = min($costs);
                $max = max($costs);
                if ($min === $max) {
                    echo wc_price($min);
                } else {
                    echo wc_price($min) . '<br/>' . wc_price($max);
                }
            } else {
                $cost = floatval(get_post_meta($post_id, '_cost_per_unit', true));
                echo $cost > 0 ? wc_price($cost) : '<span style="color:#ccc;">—</span>';
            }
        } else {
            $cost = floatval(get_post_meta($post_id, '_cost_per_unit', true));
            echo $cost > 0 ? wc_price($cost) : '<span style="color:#ccc;">—</span>';
        }
    }
    if ($column === 'kimono_margin') {
        $product = wc_get_product($post_id);
        if ($product && $product->is_type('variable')) {
            $margins = [];
            foreach ($product->get_children() as $var_id) {
                $vc = floatval(get_post_meta($var_id, '_cost_per_unit', true));
                $vp = floatval(get_post_meta($var_id, '_price', true));
                if ($vc > 0 && $vp > 0) {
                    $margins[] = round(($vp - $vc) / $vp * 100);
                }
            }
            if (!empty($margins)) {
                $avg = round(array_sum($margins) / count($margins));
                $color = $avg >= 30 ? '#28a745' : ($avg >= 15 ? '#e67e22' : '#dc3545');
                echo '<span style="color:' . $color . ';font-weight:600;white-space:nowrap;">~' . $avg . '%</span>';
            } else {
                echo '—';
            }
        } else {
            $cost = floatval(get_post_meta($post_id, '_cost_per_unit', true));
            $price = floatval(get_post_meta($post_id, '_price', true));
            if ($cost > 0 && $price > 0) {
                $margin_pct = round(($price - $cost) / $price * 100);
                $color = $margin_pct >= 30 ? '#28a745' : ($margin_pct >= 15 ? '#e67e22' : '#dc3545');
                echo '<span style="color:' . $color . ';font-weight:600;white-space:nowrap;">' . $margin_pct . '%</span>';
            } else {
                echo '—';
            }
        }
    }
}, 10, 2);

// Make columns sortable
add_filter('manage_edit-product_sortable_columns', function($columns) {
    $columns['kimono_cost'] = 'kimono_cost';
    return $columns;
});

add_action('pre_get_posts', function($query) {
    if (!is_admin() || !$query->is_main_query()) return;
    if ($query->get('orderby') === 'kimono_cost') {
        $query->set('meta_key', '_cost_per_unit');
        $query->set('orderby', 'meta_value_num');
    }
});

// ═══════════════════════════════════════════════
// COST FIELD IN PRODUCT EDIT
// ═══════════════════════════════════════════════

add_action('woocommerce_product_options_pricing', function() {
    woocommerce_wp_text_input([
        'id' => '_cost_per_unit',
        'label' => 'Cost per unitate (' . get_woocommerce_currency_symbol() . ')',
        'description' => 'Cost de achizitie per unitate — folosit de Kimono BI pentru calcul marja',
        'desc_tip' => true,
        'type' => 'text',
        'data_type' => 'price',
    ]);
});

add_action('woocommerce_process_product_meta', function($post_id) {
    if (isset($_POST['_cost_per_unit'])) {
        update_post_meta($post_id, '_cost_per_unit', wc_clean($_POST['_cost_per_unit']));
    }
});

// ─── Cost field on VARIATIONS (variable products) ───

add_action('woocommerce_variation_options_pricing', function($loop, $variation_data, $variation) {
    woocommerce_wp_text_input([
        'id' => "_variation_cost_per_unit_{$loop}",
        'name' => "_variation_cost_per_unit[{$loop}]",
        'value' => get_post_meta($variation->ID, '_cost_per_unit', true),
        'label' => 'Cost per unitate (' . get_woocommerce_currency_symbol() . ')',
        'description' => 'Cost achizitie — Kimono BI',
        'desc_tip' => true,
        'type' => 'text',
        'data_type' => 'price',
        'wrapper_class' => 'form-row form-row-first',
    ]);
}, 10, 3);

add_action('woocommerce_save_product_variation', function($variation_id, $loop) {
    if (isset($_POST['_variation_cost_per_unit'][$loop])) {
        update_post_meta($variation_id, '_cost_per_unit', wc_clean($_POST['_variation_cost_per_unit'][$loop]));
    }
}, 10, 2);

// Also add cost field in the General tab for ALL product types (not just simple)
add_action('woocommerce_product_options_general_product_data', function() {
    global $post;
    $product = wc_get_product($post->ID);
    if (!$product || $product->is_type('variable')) return; // Skip for variable (cost is per variation)
    // The field is already added via woocommerce_product_options_pricing for simple products
});

// ═══════════════════════════════════════════════
// REST API — AUTHENTICATION
// ═══════════════════════════════════════════════

function kimono_bi_authenticate($request) {
    $key = $request->get_header('X-Kimono-BI-Key');
    if (!$key) $key = $request->get_param('api_key');
    if (!$key || $key !== get_option('kimono_bi_api_key')) {
        return new WP_Error('unauthorized', 'Cheie API invalida.', ['status' => 401]);
    }
    // Track last sync
    update_option('kimono_bi_last_sync', current_time('mysql'));
    return true;
}

// ═══════════════════════════════════════════════
// REST API — ENDPOINTS
// ═══════════════════════════════════════════════

add_action('rest_api_init', function() {
    register_rest_route('kimono-bi/v1', '/ping', [
        'methods' => 'GET',
        'callback' => function() { return ['status' => 'ok', 'version' => KIMONO_BI_VERSION, 'wc' => WC_VERSION, 'store' => get_bloginfo('name')]; },
        'permission_callback' => 'kimono_bi_authenticate',
    ]);

    register_rest_route('kimono-bi/v1', '/stats', [
        'methods' => 'GET', 'callback' => 'kimono_bi_get_stats', 'permission_callback' => 'kimono_bi_authenticate',
    ]);

    foreach (['orders', 'customers', 'products'] as $ep) {
        register_rest_route('kimono-bi/v1', '/' . $ep, [
            'methods' => 'GET',
            'callback' => 'kimono_bi_get_' . $ep,
            'permission_callback' => 'kimono_bi_authenticate',
            'args' => [
                'since' => ['type' => 'string', 'default' => ''],
                'page' => ['type' => 'integer', 'default' => 1],
                'per_page' => ['type' => 'integer', 'default' => 100],
            ],
        ]);
    }
});

// ─── Orders ───
function kimono_bi_get_orders($request) {
    $since = $request->get_param('since');
    $page = max(1, $request->get_param('page'));
    $per_page = min(100, max(10, $request->get_param('per_page')));

    $args = ['limit' => $per_page, 'page' => $page, 'orderby' => 'date', 'order' => 'DESC', 'type' => 'shop_order',
        'status' => ['wc-completed', 'wc-processing', 'wc-on-hold', 'wc-refunded', 'wc-cancelled', 'wc-pending', 'wc-failed']];
    if ($since) $args['date_modified'] = '>=' . $since;

    $orders = wc_get_orders($args);
    $result = [];
    foreach ($orders as $order) {
        $items = [];
        foreach ($order->get_items() as $item) {
            $prod = $item->get_product();
            $items[] = ['title' => $item->get_name(), 'quantity' => $item->get_quantity(), 'price' => (float)$item->get_total(),
                'sku' => $prod ? $prod->get_sku() : '', 'product_id' => (string)$item->get_product_id()];
        }
        $coupons = $order->get_coupon_codes();
        $result[] = [
            'id' => (string)$order->get_id(), 'order_number' => $order->get_order_number(),
            'total' => (float)$order->get_total(), 'subtotal' => (float)$order->get_subtotal(),
            'total_refunded' => (float)$order->get_total_refunded(),
            'discount_total' => (float)$order->get_total_discount(),
            'discount_code' => !empty($coupons) ? $coupons[0] : null,
            'currency' => $order->get_currency(), 'status' => $order->get_status(),
            'items_count' => $order->get_item_count(), 'line_items' => $items,
            'placed_at' => $order->get_date_created() ? $order->get_date_created()->format('c') : null,
            'fulfilled_at' => $order->get_date_completed() ? $order->get_date_completed()->format('c') : null,
            'customer_id' => (string)$order->get_customer_id(),
            'customer_email' => $order->get_billing_email(),
            'customer_first_name' => $order->get_billing_first_name(),
            'customer_last_name' => $order->get_billing_last_name(),
        ];
    }
    $total_args = $args; unset($total_args['limit'], $total_args['page']); $total_args['return'] = 'ids'; $total_args['limit'] = -1;
    $total = count(wc_get_orders($total_args));
    return ['data' => $result, 'page' => $page, 'per_page' => $per_page, 'total' => $total, 'total_pages' => ceil($total / $per_page)];
}

// ─── Customers ───
function kimono_bi_get_customers($request) {
    $page = max(1, $request->get_param('page'));
    $per_page = min(100, max(10, $request->get_param('per_page')));
    $query = new WP_User_Query(['role' => 'customer', 'number' => $per_page, 'paged' => $page, 'orderby' => 'registered', 'order' => 'DESC']);
    $result = [];
    foreach ($query->get_results() as $user) {
        $c = new WC_Customer($user->ID);
        $first = wc_get_orders(['customer_id' => $user->ID, 'limit' => 1, 'orderby' => 'date', 'order' => 'ASC', 'status' => ['wc-completed','wc-processing']]);
        $last = wc_get_orders(['customer_id' => $user->ID, 'limit' => 1, 'orderby' => 'date', 'order' => 'DESC', 'status' => ['wc-completed','wc-processing']]);
        $result[] = [
            'id' => (string)$user->ID, 'email' => $user->user_email,
            'first_name' => $c->get_first_name(), 'last_name' => $c->get_last_name(),
            'phone' => $c->get_billing_phone(),
            'orders_count' => $c->get_order_count(), 'total_spent' => (float)$c->get_total_spent(),
            'first_order_at' => !empty($first) && $first[0]->get_date_created() ? $first[0]->get_date_created()->format('c') : null,
            'last_order_at' => !empty($last) && $last[0]->get_date_created() ? $last[0]->get_date_created()->format('c') : null,
            'registered_at' => $user->user_registered,
        ];
    }
    return ['data' => $result, 'page' => $page, 'per_page' => $per_page, 'total' => $query->get_total(), 'total_pages' => ceil($query->get_total() / $per_page)];
}

// ─── Products ───
function kimono_bi_get_products($request) {
    $since = $request->get_param('since');
    $page = max(1, $request->get_param('page'));
    $per_page = min(100, max(10, $request->get_param('per_page')));
    $args = ['post_type' => ['product', 'product_variation'], 'posts_per_page' => $per_page, 'paged' => $page, 'orderby' => 'modified', 'order' => 'DESC', 'post_status' => ['publish','draft','private','inherit']];
    if ($since) $args['date_query'] = [['after' => $since, 'column' => 'post_modified']];
    $query = new WP_Query($args);
    $result = [];
    foreach ($query->posts as $post) {
        $p = wc_get_product($post->ID);
        if (!$p) continue;

        // Skip variable parent products (we export their variations instead)
        if ($p->is_type('variable')) continue;

        $cost = (float)get_post_meta($post->ID, '_cost_per_unit', true);
        if (!$cost) $cost = (float)get_post_meta($post->ID, '_wc_cog_cost', true);
        if (!$cost) $cost = (float)get_post_meta($post->ID, '_purchase_price', true);

        // For variations: build title with parent name + attribute
        $title = $p->get_name();
        $product_type = $p->get_type();
        $parent_id = null;
        if ($p->is_type('variation')) {
            $parent = wc_get_product($p->get_parent_id());
            if ($parent) {
                $attrs = $p->get_variation_attributes();
                $attr_str = implode(' / ', array_filter(array_values($attrs)));
                $title = $parent->get_name() . ($attr_str ? ' - ' . $attr_str : '');
                $parent_id = $parent->get_id();
            }
            $product_type = 'variation';
        }

        $img = $p->get_image_id() ? wp_get_attachment_url($p->get_image_id()) : '';
        if (!$img && $p->is_type('variation')) {
            $parent = wc_get_product($p->get_parent_id());
            if ($parent) $img = $parent->get_image_id() ? wp_get_attachment_url($parent->get_image_id()) : '';
        }

        $result[] = [
            'id' => (string)$p->get_id(), 'title' => $title, 'sku' => $p->get_sku(),
            'price' => (float)$p->get_price(), 'regular_price' => (float)$p->get_regular_price(),
            'cost_per_unit' => $cost, 'inventory' => $p->get_stock_quantity() ?? 0,
            'stock_status' => $p->get_stock_status(), 'product_type' => $product_type,
            'categories' => wp_list_pluck(wp_get_post_terms($post->ID, 'product_cat'), 'name'),
            'tags' => wp_list_pluck(wp_get_post_terms($post->ID, 'product_tag'), 'name'),
            'image_url' => $img, 'handle' => $p->get_slug(),
            'status' => $p->get_status() === 'publish' ? 'ACTIVE' : 'DRAFT',
        ];
    }
    return ['data' => $result, 'page' => $page, 'per_page' => $per_page, 'total' => $query->found_posts, 'total_pages' => ceil($query->found_posts / $per_page)];
}

// ─── Stats ───
function kimono_bi_get_stats() {
    global $wpdb;
    return [
        'orders' => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='shop_order'"),
        'customers' => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->users} u INNER JOIN {$wpdb->usermeta} m ON u.ID=m.user_id WHERE m.meta_key='{$wpdb->prefix}capabilities' AND m.meta_value LIKE '%customer%'"),
        'products' => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='product' AND post_status IN('publish','draft')"),
        'store_name' => get_bloginfo('name'), 'store_url' => get_site_url(),
        'currency' => get_woocommerce_currency(), 'plugin_version' => KIMONO_BI_VERSION,
    ];
}
