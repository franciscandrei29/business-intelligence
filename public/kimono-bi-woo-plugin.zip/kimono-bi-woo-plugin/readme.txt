=== Kimono BI Connector ===
Contributors: kimonogroup
Tags: woocommerce, analytics, business intelligence, bi
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
WC requires at least: 5.0
WC tested up to: 9.5
Stable tag: 1.0.0
License: GPLv2 or later

Conecteaza magazinul WooCommerce la platforma Kimono BI pentru analiza avansata de business intelligence.

== Description ==

Kimono BI Connector permite sincronizarea datelor din magazinul tau WooCommerce cu platforma Kimono BI (bi.kimonogroup.ro).

Datele exportate:
- Comenzi (total, refund, discount, line items)
- Clienti (email, nume, comenzi, total cheltuit)
- Produse (pret, stoc, cost per unitate, categorii)

Plugin-ul este lightweight si optimizat pentru shared hosting.

== Installation ==

1. Uploadeaza folderul `kimono-bi-connector` in `/wp-content/plugins/`
2. Activeaza plugin-ul din meniul Plugins
3. Mergi la WooCommerce -> Kimono BI
4. Copiaza URL-ul magazinului si Cheia API
5. In platforma Kimono BI, adauga un magazin WooCommerce cu aceste date

== Changelog ==

= 1.0.0 =
* Lansare initiala
* Endpoint-uri REST API pentru orders, customers, products
* Camp cost per unitate pe produse
* Coloana cost in lista produse admin
